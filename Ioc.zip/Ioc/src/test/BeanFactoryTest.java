package test;



import static org.junit.Assert.assertEquals;

import org.junit.Test;

import bean.BeanDefinition;
import bean.PropertyValue;
import bean.PropertyValues;
import factory.BeanFactory;
import factory.XMLBeanFactory;
import resource.LocalFileResource;

public class BeanFactoryTest {

	@Test
	public void testBeanCreateAndGet() {
		
		LocalFileResource resource = new LocalFileResource("beans.xml");
		
		BeanFactory beanFactory = new XMLBeanFactory(resource);
		// the BeanDefinition doesn`t create the real bean yet
		Dishes d = (Dishes) beanFactory.getBean("egg dishes");
		assertEquals(d.printDishes(), "Dish Name: fry eggs. Dish Price: 20.");
	}

}
